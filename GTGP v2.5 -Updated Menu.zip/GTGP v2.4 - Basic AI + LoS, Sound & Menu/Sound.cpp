#include "Sound.h"
using namespace std;

HSAMPLE *samples = NULL;


void Sound::loadSample(char* fileName)
{
	if (sound = BASS_SampleLoad(FALSE, fileName, 0, 0, 1, BASS_SAMPLE_OVER_POS))
		cout << "sample " << fileName << " loaded!" << endl;
	else
	{
		cout << "Can't load sample";
		exit(0);
	}
}

HSAMPLE Sound::getSound() {
	return sound;
}