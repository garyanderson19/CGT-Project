#pragma once
#include <string>
#include "rt3d.h"
#include "rt3dObjLoader.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "md2model.h"
#include <stack>
using namespace std;

class GameObjects {

protected:
	glm::vec3 position;
	char* name;
	GLuint objectTexture;
	GLuint objectMesh, meshIndexCount;

public:
	GameObjects();
	~GameObjects();
	glm::vec3 getPosition();
	void setPosition(glm::vec3 newPos);
	virtual void init(GLuint texID) = 0;
	
};


//Cube and subclasses of Cube
class Cube : public GameObjects {
public:
	void init(GLuint texID);
	void init(GLuint texID, GLuint mIC, GLuint mesh);
	virtual void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview) = 0;
};


class Ground : public Cube {
public:
	Ground();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};

class Wall : public Cube {
private:
	struct WallVecs {
		glm::vec3 translation{ -50.0f, 8.0f, -10.0f };
		glm::vec3 rotation{ 0.0f, 0.0f, 0.0f };
		glm::vec3 scaling{ 0.6f, 8.0f, 40.0f };
	} WV; 
public:
	Wall();
	glm::vec3 getWallVecs(int vec);
	void setWall(glm::vec3 tran, glm::vec3 rot, glm::vec3 scale);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};
//

//Player-related classes/objects
class Leg : public GameObjects {
private:
	float xRotAngle = 0.0f, zRotAngle = 0.0f;
	char *model;
public:
	Leg();
	void init(GLuint texID);
	void setModel(int m);
	void setXRotAngle(float rot);
	float getXRotAngle();
	void setZRotAngle(float rot);
	float getZRotAngle();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

class Body : public GameObjects {
public:
	Body();
	void init(GLuint texID);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

class Chair : public GameObjects {
public:
	Chair();
	void init(GLuint texID);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

class Foot : public GameObjects {
private:
	float xRotAngle = 0.0f, zRotAngle = 0.0f;
	char *model;
public:
	Foot();
	void init(GLuint texID);
	void setModel(int m);
	void setXRotAngle(float rot);
	float getXRotAngle();
	void setZRotAngle(float rot);
	float getZRotAngle();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

//player & body
class Player {
protected:
	Body body;
	Leg lLeg, rLeg;
	Foot lFoot, rFoot;
	Chair chair;

//	GLfloat dx, dz;
	GLfloat velocity = 0.0f;

public:
	Player();
	void init(GLuint texID[]);
	void moveLegs(const Uint8 keys[]);
	glm::vec3 getPosition();
	void setBodyPos(glm::vec3 newPos, GLfloat rotAngle);
	bool wallCollision(glm::vec3 pastPos, glm::vec3 &currentPos, std::vector<Wall> walls, GLfloat playerRot, GLfloat &vel);
	bool objectPlayerColl(glm::vec3 pastPos, glm::vec3 &currentPos, class LevelObj objects[], GLfloat playerRot, GLfloat &vel);

	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);

	/*

	GLfloat getDX();
	GLfloat getDZ();

	void setDX(float idx);
	void setDZ(float idy);

	*/

	void setVelocity(GLfloat vel);
	GLfloat getVelocity();
};

///////////////////////////////////////////////////////////////////////////////////////
//NPC Stuff

class NPCVision : public Cube {
private:
	glm::vec3 scaling = { 3.0f, 3.0f, 7.5f };
public:
	NPCVision();
	glm::vec3 getScaling();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview) {}
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
	void sightCollision(glm::vec3 playerPos, GLfloat angle);
};


class NPCPlayer : public Player {
private:
	NPCVision npcVision;

	//////////////////////
	md2model NPCmodel;
	GLuint playerMeshObject;
	GLuint md2VertCount = 0;
	GLuint md2Text;
	int currentAnim = 0;
	GLfloat animTime = 0.0f; bool animBounce = false;
	glm::vec3 position = { 0.0f, -2.0f, 0.0f };
	///////////////////////
public:
	NPCPlayer();
	///////////////////////////////////
	void setPosition(glm::vec3 newPos);
	glm::vec3 getPosition();
	///////////////////////////////////
	void init(GLuint texID[], GLuint mIC, GLuint mesh);
	void setBodyPos(glm::vec3 newPos, GLfloat rotAngle);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
	NPCVision getVision() {
		return npcVision;
	}
};


//text
class Text : public Cube {
private:
	string displayText;
	glm::vec3 scaling;
public:
	void selectText(int t);
	void amendText(string text);
	void setTex(GLuint tex);
	void setScaling(glm::vec3 newScale);
	void setScaling(int value, GLfloat newValue);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};


//In-game level-related objects
class LevelObj : public GameObjects {
private:
	glm::vec3 rotation = { 0.0f, 1.0f, 0.0f };
	bool addRot = false;
	glm::vec3 scaling = { 0.5f, 0.5f, 0.5f };
public:
	void setName(int n);
	void setRotation(glm::vec3 newRot);
	void addRotation();
	void setScaling(glm::vec3 newScale);
	void setScaling(int value, GLfloat newValue);
	void init(GLuint texID);
	void initLO(GLuint texID);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};


//HUD
class HUDLabel : public Cube {

};