#pragma once
#include "GameObjects.h"
#include "Sound.h"

class GameEngine {

public:
	GameEngine();
	void initSounds();
	void handleSounds(const Uint8 keys[], GLfloat playerVel, bool collision, bool launch);
	void render();
//private:
	Ground ground;
	Wall lWall, rWall, fWall, bWall, corridor[5];
	Player player;
	Sound chair_roll, smash;

	int counter = 0;


};