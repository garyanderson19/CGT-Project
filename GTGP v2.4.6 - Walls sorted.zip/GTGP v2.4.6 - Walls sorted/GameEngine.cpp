#include "GameEngine.h"

GameEngine::GameEngine() {
	//player.init();
	//ground.init();
}

void GameEngine::initSounds() {
	/* Initialize default output device */
	if (!BASS_Init(-1, 44100, 0, 0, NULL))
		cout << "Can't initialize device";

	/* Load a sample from "file" and give it a max of 3 simultaneous
	playings using playback position as override decider */
	smash.loadSample("Smash.wav");
	chair_roll.loadSample("Chair.wav");
}

void GameEngine::handleSounds(const Uint8 keys[], GLfloat playerVel, bool collision, bool launch) {

	if ((playerVel > 0.1f || playerVel < -0.1f) && counter == 1) {
		counter = 0;
	}

	if (collision == true && counter == 0) {
		HCHANNEL ch = BASS_SampleGetChannel(smash.getSound(), FALSE);
		BASS_ChannelSetAttribute(ch, BASS_ATTRIB_FREQ, 0);
		BASS_ChannelSetAttribute(ch, BASS_ATTRIB_VOL, abs(playerVel) / 1.2f);
		BASS_ChannelSetAttribute(ch, BASS_ATTRIB_PAN, -1);
		if (!BASS_ChannelPlay(ch, FALSE))
			cout << "Can't play sample" << endl;
		counter++;
	}

	if ((playerVel != 0.0f) && (BASS_ChannelIsActive(chair_roll.getSound()) != BASS_ACTIVE_PLAYING)) {
		HCHANNEL ch = BASS_SampleGetChannel(chair_roll.getSound(), FALSE);
		BASS_ChannelSetAttribute(ch, BASS_ATTRIB_FREQ, 0);
		BASS_ChannelSetAttribute(ch, BASS_ATTRIB_VOL, 0.5);
		BASS_ChannelSetAttribute(ch, BASS_ATTRIB_PAN, -1);
		if (!BASS_ChannelPlay(ch, FALSE))
			cout << "Can't play sample" << endl;
	}
	else if (playerVel == 0.0f) {
		BASS_ChannelPause(chair_roll.getSound());
		BASS_ChannelStop(chair_roll.getSound());
	}

	if (BASS_ChannelIsActive(chair_roll.getSound()) == BASS_ACTIVE_PLAYING){
		BASS_ChannelSetAttribute(chair_roll.getSound(), BASS_ATTRIB_VOL, abs(playerVel) / 0.41f);
	
	}

}

void GameEngine::render() {
	//player.render();
	//ground.render();
}