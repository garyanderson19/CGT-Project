#pragma once
#include "bass.h"
#include <iostream>
#include <SDL.h>

class Sound {
private:
	HSAMPLE sound;
public:
	void loadSample(char* fileName);
	HSAMPLE getSound();
};
