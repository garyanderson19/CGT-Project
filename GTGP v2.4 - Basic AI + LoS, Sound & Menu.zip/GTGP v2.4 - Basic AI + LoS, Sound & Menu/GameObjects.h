#pragma once
#include <string>
#include "rt3d.h"
#include "rt3dObjLoader.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include "md2model.h"
#include <stack>
using namespace std;

class GameObjects {

protected:
	glm::vec3 position;
	string name;
	GLuint objectTexture;
	GLuint objectMesh, meshIndexCount;

public:
	GameObjects();
	~GameObjects();
	glm::vec3 getPosition();
	void setPosition(glm::vec3 newPos);
	virtual void init(GLuint texID) = 0;
	
};


//Cube and subclasses of Cube
class Cube : public GameObjects {
public:
	void init(GLuint texID);
	void init(GLuint texID, GLuint mIC, GLuint mesh);
	virtual void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview) = 0;
};


class Ground : public Cube {
public:
	Ground();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};

class Wall : public Cube {
private:
	struct WallVecs {
		glm::vec3 translation{ -50.0f, 8.0f, -10.0f };
		glm::vec3 rotation{ 0.0f, 0.0f, 0.0f };
		glm::vec3 scaling{ 0.6f, 8.0f, 40.0f };
	} WV; 
public:
	Wall();
	glm::vec3 getWallVecs(int vec);
	void setWall(glm::vec3 tran, glm::vec3 rot, glm::vec3 scale);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};
//

//Player-related classes/objects
class Leg : public GameObjects {
private:
	float xRotAngle = 0.0f, zRotAngle = 0.0f;
	char *model;
public:
	Leg();
	void init(GLuint texID);
	void setModel(int m);
	void setXRotAngle(float rot);
	float getXRotAngle();
	void setZRotAngle(float rot);
	float getZRotAngle();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

class Body : public GameObjects {
public:
	Body();
	void init(GLuint texID);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

class Chair : public GameObjects {
public:
	Chair();
	void init(GLuint texID);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

class Foot : public GameObjects {
private:
	float xRotAngle = 0.0f, zRotAngle = 0.0f;
	char *model;
public:
	Foot();
	void init(GLuint texID);
	void setModel(int m);
	void setXRotAngle(float rot);
	float getXRotAngle();
	void setZRotAngle(float rot);
	float getZRotAngle();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
};

//player & body
class Player {
protected:
	Body body;
	Leg lLeg, rLeg;
	Foot lFoot, rFoot;
	Chair chair;

//	GLfloat dx, dz;
	GLfloat velocity = 0.0f;

public:
	Player();
	void init(GLuint texID[]);
	void moveLegs(const Uint8 keys[]);
	glm::vec3 getPosition();
	void setBodyPos(glm::vec3 newPos, GLfloat rotAngle);
	bool wallCollision(glm::vec3 pastPos, glm::vec3 &currentPos, Wall walls[], GLfloat playerRot, GLfloat &vel);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);

	/*

	GLfloat getDX();
	GLfloat getDZ();

	void setDX(float idx);
	void setDZ(float idy);

	*/

	void setVelocity(GLfloat vel);
	GLfloat getVelocity();
};

///////////////////////////////////////////////////////////////////////////////////////
//NPC Stuff

class NPCVision : public Cube {
private:
	glm::vec3 scaling = { 3.0f, 3.0f, 7.5f };
public:
	NPCVision();
	glm::vec3 getScaling();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview) {}
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
	void sightCollision(glm::vec3 playerPos, GLfloat angle);
};


class NPCPlayer : public Player {
private:
	NPCVision npcVision;

public:
	NPCPlayer();
	void init(GLuint texID[], GLuint mIC, GLuint mesh);
	void setBodyPos(glm::vec3 newPos, GLfloat rotAngle);
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview, GLfloat rotAngle);
	NPCVision getVision() {
		return npcVision;
	}
};


//text
class Title : public Cube {
public:
	Title();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};

//class Text{
//private:
//	Play play;
//	Inst inst;
//	Exit exit;
//
//public:
//	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
//};

class Play : public Cube {
public:
	Play();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};

class Inst : public Cube {
public:
	Inst();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};

class Exit : public Cube {
public:
	Exit();
	void render(rt3d::materialStruct material, GLuint &shader, stack<glm::mat4> &modelview);
};