#include "GameEngine.h"

GameEngine::GameEngine() {
	//player.init();
	//ground.init();
}

void GameEngine::render() {
	//player.render();
	//ground.render();
}