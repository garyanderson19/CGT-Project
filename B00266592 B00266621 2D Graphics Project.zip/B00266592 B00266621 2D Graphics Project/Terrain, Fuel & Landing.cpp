#include <gl/glut.h>
#include <iostream>
#include "random.h"
#include "Terrain, Fuel & Landing.h"
#include "Shapes.h"
using namespace std;

float win_width = 1112, win_height = 806;
float landing_start, landing_end, landing_y;

const int points = 50;
float pointx[points], pointy[points];


//Trapezium starting point = halfway across window - trapeziums width/2 - length between the bottom left corner of the trapezium top left cornerextension length
//rec_offset = Offset of the rectangle required to place it in the centre of the lander
float trap_start_pos = 55 * win_width / 120;
float rec_offset = win_width / 9;

//Setting up the bottom of the lander, the trapezium, and the top of the lander, which is a Shape that will change depending on the user's input
Trap t(trap_start_pos, win_height / 1.3, 0, 0, win_width / 60, win_width / 20, win_width / 30);
Shape *lander_top;

//Declaring variables that store the value of the midpoint of the trapezium and the y position of the Shape atop the trapezium
float trap_midpoint = t.getX() + t.getExt() + 0.5*t.getWidth();
float lander_top_y = t.getY() + t.getHeight();

//Handles which shape represents the top of the lander
void set_lander_top(int itop){

	switch (itop){
	/*For circle (starts in centre)
	radius doesn't matter
	CENTRE x = trapezium midpoint
	CENTRE y = Top of trapezium + radius*/
	case 0:
		lander_top = new Circle(trap_midpoint, lander_top_y + win_width/25, win_width / 25, t.getDX(), t.getDY());
		break;
	/*	For rectangle (starts at bottom left corner)
	x = trapezium midpoint - 1/2 the rectangle's width
	y = trapezium y + trapezium height*/
	case 1:
		lander_top = new Rect(trap_midpoint - 0.5*rec_offset, lander_top_y, rec_offset, win_height / 15, t.getDX(), t.getDY());
		break;
	/*For triangle (starts from bottom left point)
	height doesn't matter
	x = trapezium midpoint - 1/2 the width of the triangle
	y = trapezium y + trapezium height*/
	case 2:
		lander_top = new Triangle(trap_midpoint - 0.5*(rec_offset - win_width / 30), lander_top_y, win_height / 10, rec_offset - win_width / 30, t.getDX(), t.getDY());
		break;
	}
}

//When the shape of the top of the lander changes, this function makes sure the top follows the bottom of the lander
void change_lander_top(int itop){

	float new_trap_midpoint = t.getX() + t.getExt() + 0.5*t.getWidth();
	float new_lander_top_y = t.getY() + t.getHeight();

	lander_top->setDX(t.getDX());
	lander_top->setDY(t.getDY());
	
	switch (itop){
	case 0:
		lander_top->setX(new_trap_midpoint);
		lander_top->setY(new_lander_top_y + win_width/25);
		break;
	case 1:
		lander_top->setX(new_trap_midpoint - 0.5*rec_offset);
		lander_top->setY(new_lander_top_y);
		break;
	case 2:
		lander_top->setX(new_trap_midpoint - 0.5*(rec_offset - win_width / 30));
		lander_top->setY(new_lander_top_y);
		break;
	}
}
	
//Handles moving the entire lander
void lander_move(float x, float y)
{	
	//Moves the trapezoid and shape on top by (x, y)
	t.move(x, y);
	lander_top->move(x, y);
}

//Displays the entire lander
void show_lander()
{
	t.show();
	lander_top->show();
}

//Repositions the entire lander to its original position
void reposition_lander(int top)
{
	t.setX(trap_start_pos);
	t.setY(win_height / 1.3);
	//Runs if the top of the lander is a circle
	if (top == 0){
		lander_top->setX(trap_midpoint);
		lander_top->setY(lander_top_y + win_width / 25);
	}
	//Runs if the top of the lander is a rectangle or triangle
	else if (top == 1 || top == 2)
	{
		if (top == 1)
			lander_top->setX(trap_midpoint - 0.5*rec_offset);
		else if (top == 2)
			lander_top->setX(trap_midpoint - 0.5*(rec_offset - win_width / 30));
		lander_top->setY(lander_top_y);
	}
	//Resets the change in speed of the lander
	t.setDX(0);
	lander_top->setDX(0);
	t.setDY(0);
	lander_top->setDY(0);
}

//Sets up and displays a randomly generated terrain with an area for landing the lander that gets smaller as the user progresses through levels
float setRandomTerrain(int level){

	float a = win_height / 6, b = win_height / 3;
	//Sets a random height for the height of the landing strip, and a random beginning point for it, as well as the length of the landing strip which depends on the level 
	landing_y = rnd(a*1.2, b / 1.2);
	landing_start = rnd(0, (points / 1.25) - 1) + 1;
	landing_end = landing_start + (points / (5 + level));

	for (int i = 1; i < points; i++){
		//Sets x coordinate of point i
		pointx[i] = (i*win_width) / points + rnd(0, (i*win_width) / (points*points));
		//Sets y coordinate of point i. If it is part of the landing strip the y coordinate is made to equal a certain height, otherwise it is made to equal a random height
		if (i < landing_start || i >= landing_end)
			pointy[i] = rnd(a, b);
		else
			pointy[i] = landing_y;

	}
	return landing_y;
}
void showRandomTerrain(int level){
	
	//Displays the terrain in a different colour depending on the level
	if (level == 1)
		glColor3f(0.2, 0.4, 0.1);
	else if (level == 2)
		glColor3f(0.57, 0.2, 0.2);
	else if (level == 3)
		glColor3f(0.07, 0.1, 0.4);

	//Draws quadrilateral strips, with the coordinates going from bottom left corner to top left corner to bottom right corner to top right corner
	glBegin(GL_QUAD_STRIP);
		glVertex2f(0, 0);
		glVertex2f(0, win_height / 4);
		glVertex2f(pointx[1], 0);
		glVertex2f(pointx[1], pointy[1]);
		for (int i = 1; i < points-1; i++)
		{
			glVertex2f(pointx[i], 0);
			glVertex2f(pointx[i], pointy[i]);
			glVertex2f(pointx[i + 1], 0);
			glVertex2f(pointx[i + 1], pointy[i + 1]);
		}
		glVertex2f(pointx[49], 0);
		glVertex2f(pointx[49], pointy[49]);
		glVertex2f(win_width, 0);
		glVertex2f(win_width, win_height / 5);
	glEnd();

	//Sets colour to black and begins drawing lines just above the terrain
	glColor3f(0, 0, 0);
	glLineWidth(1.5);
	glBegin(GL_LINE_STRIP);
		glVertex2f(0, win_height / 4 + win_height/800);
		for (int i = 1; i < points; i++)
		{
			glVertex2f(pointx[i], pointy[i] + win_height / 800);
		}
		glVertex2f(win_width, win_height / 5 + win_height / 800);
	glEnd();
}

//Gets the coordinates of the terrain and stores them in arrays that the program uses
float* getPoints(float xpoints[], float ypoints[])
{
	for (int i = 0; i < points; i++)
	{
		xpoints[i] = pointx[i];
		ypoints[i] = pointy[i];
	}
	return xpoints, ypoints;
}

//Tests if the lander has collided with the landing strip or other parts of the terrain and decides if the user has won or not, returning that answer
bool landing(int level, bool win, float xpo[], float ypo[], bool& collide)
{
	t.checkCollision(xpo, ypo, landing_start, landing_y, landing_end, t, lander_top, win, collide);
	return win;
}