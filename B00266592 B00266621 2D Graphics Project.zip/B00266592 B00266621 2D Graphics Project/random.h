#ifndef RANDOM_H
#define RANDOM_H

float rnd();
float rnd(float rangemin, float rangemax);
int rnd(int range);

#endif