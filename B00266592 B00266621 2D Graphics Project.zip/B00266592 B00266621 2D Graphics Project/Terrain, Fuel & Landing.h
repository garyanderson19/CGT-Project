#include <gl/glut.h>
#include <iostream>
#include "random.h"
using namespace std;

float setRandomTerrain(int level);
void showRandomTerrain(int level);
void set_lander_top(int itop);
void change_lander_top(int itop);
void show_lander();
void lander_move(float x, float y);
void reposition_lander(int top);
bool fuel();
void show_fuel();
float* getPoints(float xpoints[], float ypoints[]);
bool landing(int level, bool win, float xpo[], float ypo[], bool& collide);