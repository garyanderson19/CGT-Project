#include <gl/glut.h>
#include <iostream>
#include <cmath>
#include "random.h"
#include "Shapes.h"
#include "Terrain, Fuel & Landing.h"
using namespace std;

//Abstract Shape class method definitions
Shape::Shape(float ix, float iy, float idx, float idy)
{
	x = ix;
	y = iy;
	dx = idx;
	dy = idy;
}

void Shape::move(float idx, float idy)
{
	//Changes the speed at which the Shape moves horizontally
	dx += idx;
	x += dx;
	
	//Applies downwards gravity to the Shape and changes its vertical speed
	float g = -0.00000015;
	dy += g + idy;
	y += dy;
}

float Shape::getX()
	{
		return x;
	}

float Shape::getY()
	{
		return y;
	}

float Shape::getDX()
	{
		return dx;
	}

float Shape::getDY()
	{
		return dy;
	}

void Shape::setX(float ix)
{
	x = ix;
}

void Shape::setY(float iy)
{
	y = iy;
}

void Shape::setDX(float idx)
{
	dx = idx;
}

void Shape::setDY(float idy)
{
	dy = idy;
}

//Circle class method definitions
void Circle::show()
{
	glBegin(GL_POLYGON);
		const int NPOINTS = 60;
		const float TWOPI = 2 * 3.1415927;
		const float STEP = TWOPI / NPOINTS;
		for (float angle = 0; angle < TWOPI; angle += STEP)
			glVertex2f(x + radius*cos(angle), y + radius*sin(angle));
	glEnd();
}

//Rectangle class method definitions
void Rect::show()
{
	//Plots a rectangle starting at its bottom left corner
	glBegin(GL_POLYGON);
	glVertex2f(x, y);
	glVertex2f(x + width, y);
	glVertex2f(x + width, y + height);
	glVertex2f(x, y + height);
	glEnd();
}

float Rect::getWidth()
{
	return width;
}

void Rect::setWidth(float iwidth)
{
	width = iwidth;
}

//Triangle class method definitions
void Triangle::show()
	{
	//Plots a triangle starting from its bottom left corner
		glBegin(GL_POLYGON);
		glVertex2f(x, y);
		glVertex2f(x + 0.5*base, y + height);
		glVertex2f(x + base, y);
		glEnd();
	}

//Trapezoid class method definitions
void Trap::show()
{
	//Plots a trapezium starting from its bottom left corner
	glBegin(GL_POLYGON);
	glVertex2f(x, y);
	glVertex2f(x + ext, y + height);
	glVertex2f(x + ext + width, y + height);
	glVertex2f(x + 2 * ext + width, y);
	glEnd();
}

float Trap::getExt()
{
	//Returns the size of the width between the bottom left and top left corner of the trapezium
	return ext;
}

float Trap::getWidth()
{
	return width;
}

float Trap::getHeight()
{
	return height;
}

//Checks the collision between the lander and the terrain
bool Trap::checkCollision(float xpoints[], float ypoints[], int xlanding, float ylanding, int land_end, Trap t, Shape* l, bool& win, bool& colli)
{
	if (!colli){
		//Checks collisions for points before the landing strip
		for (int i = 1; i < xlanding + 1; i++){
			//If point i in the terrain is higher than point i+1 in the terrain
			if (ypoints[i] > ypoints[i + 1])
			{
				//If the height of the bottom of the lander is between the heights of point i and point i+1 in the terrain
				if ((t.getY() < ypoints[i]) && (t.getY() > ypoints[i + 1])){
					//If the x coordinates of the bottom left or bottom right points of the lander are between the x coordinates of point i and point i+1 on the terrain
					if (((t.getX() > xpoints[i]) && (t.getX() < xpoints[i + 1])) || (((t.getX() + t.getWidth()) > xpoints[i]) && ((t.getX() + t.getWidth()) < xpoints[i + 1])))
					{
						//Then there is a collision
						colli = true;
					}
				}
			}
			//Or if point i in the terrain is lower than point i+1 in the terrain
			else if (ypoints[i] < ypoints[i + 1])
			{
				//Do the same as the above
				if ((t.getY() > ypoints[i]) && (t.getY() < ypoints[i + 1])){
					if (((t.getX() > xpoints[i]) && (t.getX() < xpoints[i + 1])) || (((t.getX() + t.getWidth()) > xpoints[i]) && ((t.getX() + t.getWidth()) < xpoints[i + 1])))
					{
						colli = true;
					}
				}
			}
		}

		//Checks collisions for points after the landing strip
		for (int i = land_end; i < 49; i++){
			if (ypoints[i] > ypoints[i + 1])
			{
				if ((t.getY() < ypoints[i]) && (t.getY() > ypoints[i + 1])){
					if (((t.getX() > xpoints[i]) && (t.getX() < xpoints[i + 1])) || (((t.getX() + t.getWidth()) > xpoints[i]) && ((t.getX() + t.getWidth()) < xpoints[i + 1])))
					{
						colli = true;
					}
				}
			}
			else if (ypoints[i] < ypoints[i + 1])
			{
				if ((t.getY() > ypoints[i]) && (t.getY() < ypoints[i + 1])){
					if (((t.getX() > xpoints[i]) && (t.getX() < xpoints[i + 1])) || (((t.getX() + t.getWidth()) > xpoints[i]) && ((t.getX() + t.getWidth()) < xpoints[i + 1])))
					{
						colli = true;
					}
				}
			}
		}

		//If the landers bottom left and bottom right corners are within the x coordinates of the beginning and end of the landing strip AND the height of the bottom of the lander is on the landing strip
		if ((t.getX() > xpoints[xlanding + 1]) && ((t.getX() + t.getWidth()) < xpoints[land_end]) && (t.getY() <= ylanding) && (t.getY() > (ylanding - 100)))
		{
			//If the lander is moving too fast
			if (t.getDY() < -0.006)
			{
				//There is a collision
				colli = true;
			}
			//Or if the lander is slow enough
			else
			{
				//The player wins the level
				win = true;
			}
		}
	}
	return win;
}