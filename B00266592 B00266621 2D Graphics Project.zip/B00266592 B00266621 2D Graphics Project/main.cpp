#include<iostream>
#include<gl/glut.h>
//Using Alistair McMonnies' Bitmap code to display Bitmaps
#include "Bitmap.h"
#include "random.h"
#include "Terrain, Fuel & Landing.h"
#include "Shapes.h"
using namespace std;

float windowWidth = 1112;
float windowHeight = 806;
bool mouseActive = false;
bool clearScreen = true;
bool out_of_fuel = false, complete = false, collided = false;
int level_num = 0;
int top = 0;
float mouseX, mouseY;
float lastX, lastY;
float xpo[50], ypo[50];
Bitmap *background;
Bitmap *background2;
Bitmap *background3;
Bitmap *background4;
string message="Fuel:";

//Sets up fuel gauge
Rect *fuel_gauge = new Rect(windowWidth / 10, windowHeight / 1.143, windowWidth / 2.8, windowHeight / 18, 0, 0);

void showInstructions(){
	//Displays instructions in the command module
	cout << "		Instructions" << endl;
	cout << "***********************************************" << endl;
	cout << endl;
	cout << "Aim: The goal is to successfuly land the lunar lander on the straight part of " << endl;
	cout << "the terrain at a safe speed before your fuel runs out." << endl;
	cout << "If you go too fast you will crash! Make sure you're travelling slow enough." << endl;
	cout << "If you fly into the spiky parts of the terrain you will crash!" << endl;
	cout << "Make sure the entirety of your lander is on the landing strip" << endl;
	cout << "as any sort of gap could leave you open to attack from aliens and you'll die!" << endl;
	cout << "Use the left and right arrow keys to move the lander horizontally." << endl;
	cout << "Use the up arrow key to slow the lander down." << endl;
	cout << "Press the 's' key to switch the shape of the top of the lander!" << endl;
	cout << "Hold the right mouse button down to open the quick menu." << endl;
	cout << "Press the 'q' key at any time to quit the game." << endl;
	cout << endl << "" << endl;
}

void resetLevel()
{
	//Resets the fuel gauge
	out_of_fuel = false;
	fuel_gauge->setWidth((windowWidth / 2.8) / level_num);
	//Sets up the terrain and moves the lander back to its original position
	setRandomTerrain(level_num);
	reposition_lander(top);
	complete = false;
}

//Handles the fuel functions
bool fuel()
{
	//If the fuel gauge isn't empty, decrease it's width by an amount
	if (fuel_gauge->getWidth() > 1)
		fuel_gauge->setWidth(fuel_gauge->getWidth() - (windowWidth / (800- 100*level_num)));
	//Or if it is empty, the user is out of fuel
	else
	{
		fuel_gauge->setWidth(0);
		out_of_fuel = true;
	}
	return out_of_fuel;
}

void show_fuel()
{
	//If the user is not out of fuel, show the fuel gauge
	if (!out_of_fuel)
		fuel_gauge->show();
}

//Handles user input from the keyboard
void keyboard(unsigned char key, int x, int y)
{
	switch (key) {
	case '1':
		//Changes to level 1 and resets the level 
		level_num = 1;
		resetLevel();
		break;
	case '2':
		//Changes to level 2 and resets the level
		level_num = 2;
		resetLevel();
		break;
	case '3':
		//Changes to level 3 and resets the level
		level_num = 3;
		resetLevel();
		break;
	case'4':
		//Displays the instructions in the command module
		showInstructions();
		break;
	case 's':
		//Changes the value of the variable representing which shape sits at the top of the lander, then sets the new lander top as this shape
		if (top < 2)
			top++;
		else
			top = 0;
		set_lander_top(top);
		change_lander_top(top);
		break;
	case 'q':
		//Exits the program
		exit(0);
		break;

	}
}

void special_keys(int value, int x, int y)
{
	//Moves the lander in a specific direction based on which of the left, right and up arrow keys are pressed
	 switch (value) {
	 case GLUT_KEY_LEFT:
		 lander_move(-windowWidth / 5000000, 0);
		 break;
	 case GLUT_KEY_RIGHT:
		 lander_move(windowWidth / 5000000, 0);
		 break;
	 case GLUT_KEY_UP:
		 fuel();
		 if (!out_of_fuel)
			 lander_move(0, windowHeight / 6000000);
		 break;
		 }
} 

 //Handles drawing a string of text to the screen
void drawString(void *font, float x, float y, string s) {
	 //Draws a string 's' in a font and size represented by 'font' at position (x, y, 0)
	 const char* str = s.c_str();
	 char *ch;
	 glRasterPos3f(x, y, 0.0);
	 for (ch = (char*)str; *ch; ch++)
		 glutBitmapCharacter(font, (int)*ch);
 }

//Handles the sub-menu actions
void handle_menu(int item){
	
	switch (item) {
	//If the first option is selected then the game returns to the main menu, or 'Level 0'
	case 1:
		level_num = 0;
		break;
	//If the second option is selected then the game resets the level
	case 2:
		resetLevel();
		break;
	//If the third option is selected then the instructions are displayed on the command module
	case 3:
		showInstructions();
		break;
	//If the fourth option is selected then the program ends
	case 4:
		exit(0);
		break;
	}
}

//Initialises the sub-menu
void init_menu()
{
	//Creates a menu
	glutCreateMenu(handle_menu);

	//Adds captions for each option in the menu and attaches them to a value which the function for handling the menu will use
	glutAddMenuEntry("Menu", 1);
	glutAddMenuEntry("Restart", 2);
	glutAddMenuEntry("Instructions", 3);
	glutAddMenuEntry("Quit", 4);

	//Attaches the action of accessing the menu to the right mouse button
	glutAttachMenu(GLUT_RIGHT_BUTTON);
}

//Performs actions at the beginning of the program
void init()
{
	//Loads bitmaps used as backgrounds
	background = new Bitmap("menu.bmp", false);
	background2 = new Bitmap("level 1.bmp", false);	
	background3 = new Bitmap("level 2.bmp", false);
	background4 = new Bitmap("level 3.bmp", false);

}


//Handles actions used to display different objects
void display()
{
	glClear(GL_COLOR_BUFFER_BIT);
	
	//If the lander has collided with the part(s) of the terrain that are not part of the landing strip then the level is restarted 
	if (collided)
	{
		resetLevel();
		collided = false;
	}

	//Draw a specific background depending on which level the user is on
	if(level_num == 0)
		background->draw(0, 0, windowWidth, windowHeight);
	else if (level_num == 1)
		background2->draw(0, 0, windowWidth, windowHeight);
	else if (level_num == 2)
		background3->draw(0, 0, windowWidth, windowHeight);
	else if (level_num == 3)
		background4->draw(0, 0, windowWidth, windowHeight);

	//If the user is on a level other than 'Level 0' (the main menu)
	if (level_num != 0)
	{
		//Draws a string of text in red, in Helvetica size 18, at position (1/20 of the width of the window, the height of the window/1.12)
		glColor3f(1, 0, 0);
		drawString(GLUT_BITMAP_HELVETICA_18, windowWidth / 20, windowHeight / 1.12, message);

		//Draws the fuel gauge in orange
		glColor3f(1, 0.5, 0);
		show_fuel();

		//Draws the lander in grey
		glColor3f(0.38, 0.38, 0.38);
		show_lander();

		//Draws the terrain, with the level number influencing how it's drawn
		showRandomTerrain(level_num);

		//Gets the coordinates of all the points on the terrain and tests if the lander has collided with it
		getPoints(xpo, ypo);
		complete = landing(level_num, complete, xpo, ypo, collided);
		lander_move(0, 0);
	}
	glColor3f(1, 1, 1);
	glFlush();
	glutPostRedisplay();
	if (complete && level_num < 4)
	{
		level_num++;
		resetLevel();
	}
	else if (level_num >= 4)
		level_num = 0;
}

//Main function of the program
int main(int argc, char **argv){
	
	//Sets up OpenGL
	glutInit(&argc, argv);
	glutInitWindowSize(windowWidth, windowHeight);
	glutInitDisplayMode(GLUT_SINGLE | GLUT_RGBA);
	glutInitWindowPosition(250, 80);
	glutCreateWindow("Menus");
	glClearColor(1.0, 1.0, 1.0, 0.0);
	gluOrtho2D(0, windowWidth, 0, windowHeight);
	
		//Sets the shape of the top of the lander to a circle
		set_lander_top(top);
	
	glutDisplayFunc(display);
	glutIdleFunc(display);
	glutKeyboardFunc(keyboard);
	glutSpecialFunc(special_keys);
	
		//Loads the backgrounds for the levels and menu
		init();
	
		//Sets up the right mouse button menu options
		init_menu();
	
	glutMainLoop();
		
		//Delete bitmaps from memory
		delete background, background2, background3, background4;
	
		return 0;
}