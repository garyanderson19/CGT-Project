#include <gl/glut.h>
#include <iostream>
#include <cmath>
using namespace std;

//Abstract Shape class definition
class Shape
{
public:
	//Constructor
	Shape(float ix, float iy, float idx, float idy);
	//Methods
	virtual void show() = 0;
	void move(float idx, float idy);
	//virtual void checkCollision(float xpoints[], float ypoints[], float landing, bool win) = 0;
	//Accessor functions
	float getX();
	float getY();
	float getDX();
	float getDY();
	void setX(float ix);
	void setY(float iy);
	void setDX(float idx);
	void setDY(float idy);
protected:
	float x, y, dx, dy;
};

//Circle class definition
class Circle : public Shape
{
public:
	//Constructor
	Circle(float ix, float iy, float iradius, float idx, float idy) :Shape(ix, iy, idx, idy)
	{
		radius = iradius;
	}
	void show();
private:
	float radius;
};

//Rectangle class definition
class Rect : public Shape
{
public:
	Rect(float ix, float iy, float iwidth, float iheight, float idx, float idy) :Shape(ix, iy, idx, idy)
	{
		width = iwidth;
		height = iheight;
	}
	void show();
	float getWidth();
	void setWidth(float iwidth);
private:
	float width, height;
};

//Triangle class definition
class Triangle : public Shape
{
public:
	Triangle(float ix, float iy, float iheight, float ibase, float idx, float idy) :Shape(ix, iy, idx, idy)
	{
		height = iheight;
		base = ibase;
	}
	void show();
private:
	float height, base;
};

//Trapezoid class definition
class Trap : public Shape
{
public:
	Trap(float ix, float iy, float idx, float idy, float iext, float iwidth, float iheight) : Shape(ix, iy, idx, idy)
	{
		ext = iext;
		width = iwidth;
		height = iheight;
	}
	void show();
	bool checkCollision(float xpoints[], float ypoints[], int xlanding, float ylanding, int land_end, Trap t, Shape *lander_top, bool& win, bool& colli);
	float getExt();
	float getWidth();
	float getHeight();
private:
	float ext, width, height;
};